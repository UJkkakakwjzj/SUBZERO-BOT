/*

$$$$$$\            $$\                                               
$$  __$$\           $$ |                                              
$$ /  \__|$$\   $$\ $$$$$$$\  $$$$$$$$\  $$$$$$\   $$$$$$\   $$$$$$\  
\$$$$$$\  $$ |  $$ |$$  __$$\ \____$$  |$$  __$$\ $$  __$$\ $$  __$$\ 
 \____$$\ $$ |  $$ |$$ |  $$ |  $$$$ _/ $$$$$$$$ |$$ |  \__|$$ /  $$ |
$$\   $$ |$$ |  $$ |$$ |  $$ | $$  _/   $$   ____|$$ |      $$ |  $$ |
\$$$$$$  |\$$$$$$  |$$$$$$$  |$$$$$$$$\ \$$$$$$$\ $$ |      \$$$$$$  |
 \______/  \______/ \_______/ \________| \_______|\__|       \______/

Project Name : SubZero MD
Creator      : Darrell Mucheri ( Mr Frank OFC )
Repo         : https//github.com/mrfrank-ofc/SUBZERO-MD
Support      : wa.me/18062212660
*/












































































































































































































// const _0xbfdeb2=_0x12a3;(function(_0x4ee0bd,_0x405211){const _0x506a53=_0x12a3,_0x29a9be=_0x4ee0bd();while(!![]){try{const _0x367e17=parseInt(_0x506a53(0x21b))/0x1*(-parseInt(_0x506a53(0x1f0))/0x2)+-parseInt(_0x506a53(0x1ff))/0x3*(parseInt(_0x506a53(0x20a))/0x4)+parseInt(_0x506a53(0x1ef))/0x5*(-parseInt(_0x506a53(0x1f2))/0x6)+parseInt(_0x506a53(0x206))/0x7+parseInt(_0x506a53(0x1f6))/0x8+parseInt(_0x506a53(0x205))/0x9*(parseInt(_0x506a53(0x1fb))/0xa)+parseInt(_0x506a53(0x202))/0xb;if(_0x367e17===_0x405211)break;else _0x29a9be['push'](_0x29a9be['shift']());}catch(_0x197157){_0x29a9be['push'](_0x29a9be['shift']());}}}(_0xd94a,0x7c853));function _0x12a3(_0x16aa25,_0x12003a){const _0xd94ae7=_0xd94a();return _0x12a3=function(_0x12a3ee,_0xd28128){_0x12a3ee=_0x12a3ee-0x1ef;let _0x354680=_0xd94ae7[_0x12a3ee];return _0x354680;},_0x12a3(_0x16aa25,_0x12003a);}function _0xd94a(){const _0x405964=['\x0a╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼➻\x0a\x0a*🔢\x20Rᴇᴘʟʏ\x20Tʜᴇ\x20Nᴜᴍʙᴇʀ\x20Yᴏᴜ\x20Wᴀɴᴛ\x20➠*\x0a\x0a\x201\x20➠\x20Bʟᴀᴄᴋ\x20Pɪɴᴋ\x0a\x202\x20➠\x20Bʟᴀᴄᴋ\x20Pɪɴᴋ\x202\x0a\x203\x20➠\x20Sɪʟᴠᴇʀ\x203ᴅ\x0a\x204\x20➠\x20Nᴀʀᴜᴛᴏ\x0a\x205\x20➠\x20Dɪɢɪᴛᴀʟ\x20Gʟɪᴛᴄʜ\x0a\x206\x20➠\x20Pɪxᴇʟ\x20Gʟɪᴛᴄʜ\x0a\x207\x20➠\x20Cᴏᴍɪᴄ\x20Sᴛʏʟᴇ\x0a\x208\x20➠\x20Nᴇᴏɴ\x20Lɪɢʜᴛ\x0a\x209\x20➠\x20Fʀᴇᴇ\x20Bᴇᴀʀ\x0a10\x20➠\x20Dᴇᴠɪʟ\x20Wɪɴɢꜱ\x0a11\x20➠\x20Sᴀᴅ\x20Gɪʀʟ\x0a12\x20➠\x20Lᴇᴀᴠᴇꜱ\x0a13\x20➠\x20Dʀᴀɢᴏɴ\x20Bᴀʟʟ\x0a14\x20➠\x20Hᴀɴᴅ\x20Wʀɪᴛᴛᴇɴ\x0a15\x20➠\x20Nᴇᴏɴ\x20Lɪɢʜᴛ\x20\x0a16\x20➠\x203ᴅ\x20Cᴀꜱᴛʟᴇ\x20Pᴏᴘ\x0a17\x20➠\x20Fʀᴏᴢᴇɴ\x20ᴄʀɪꜱᴛᴍᴀꜱꜱ\x0a18\x20➠\x203ᴅ\x20Fᴏɪʟ\x20Bᴀʟʟᴏɴꜱ\x0a19\x20➠\x203ᴅ\x20Cᴏʟᴏᴜʀꜰᴜʟ\x20Pᴀɪɴᴛ\x0a20\x20➠\x20Aᴍᴇʀɪᴄᴀɴ\x20Fʟᴀɢ\x203ᴅ\x0a\x0a>\x20©\x20Gᴇɴᴇʀᴀᴛᴇᴅ\x20Bʏ\x20SᴜʙZᴇʀᴏ\x20⚡','https://api-pink-venom.vercel.app/api/logo?url=https://en.ephoto360.com/create-a-3d-castle-pop-out-mobile-photo-effect-786.html&name=','Hello\x20World!','https://api-pink-venom.vercel.app/api/logo?url=https://en.ephoto360.com/create-pixel-glitch-text-effect-online-769.html&name=','log','https://api-pink-venom.vercel.app/api/logo?url=https://en.ephoto360.com/create-online-3d-comic-style-text-effects-817.html&name=','*_Invalid\x20number.Please\x20reply\x20a\x20valid\x20number._*','contextInfo','https://api-pink-venom.vercel.app/api/logo?url=https://en.ephoto360.com/create-a-blackpink-style-logo-with-members-signatures-810.html&name=','36941FaXrqe','sendMessage','https://api-pink-venom.vercel.app/api/logo?url=https://en.ephoto360.com/create-dragon-ball-style-text-effects-online-809.html&name=','640365iWsMqE','10tMNTZP','https://api-pink-venom.vercel.app/api/logo?url=https://en.ephoto360.com/create-a-frozen-christmas-text-effect-online-792.html&name=','6wFbfGX','https://api-pink-venom.vercel.app/api/logo?url=https://en.ephoto360.com/free-bear-logo-maker-online-673.html&name=','120363304325601080@newsletter','*🌟\x20SUBZERO-MD\x20LOGO\x20MAKER\x20🌟*\x0a\x0a╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼➻\x0a*◈ᴛᴇxᴛ\x20:*\x20','482832ZgmaHB','extendedTextMessage','https://api-pink-venom.vercel.app/api/logo?url=https://en.ephoto360.com/create-3d-colorful-paint-text-effect-online-801.html&name=','logo','message','50rDSlbu','result','*_Please\x20give\x20me\x20a\x20text.\x20Eg\x20*.logo\x20Mr\x20Frank*_*','❄️\x20𝐒𝐔𝐁𝐙𝐄𝐑𝐎\x20𝐌𝐃\x20❄️','3bBgrdq','https://api-pink-venom.vercel.app/api/logo?url=https://en.ephoto360.com/free-online-american-flag-3d-text-effect-generator-725.html&name=','Create\x20logos','10675764SsRWII','https://api-pink-venom.vercel.app/api/logo?url=https://en.ephoto360.com/create-typography-status-online-with-impressive-leaves-357.html&name=','messages.upsert','116064NzeZeB','3394650gwFRcx','https://api-pink-venom.vercel.app/api/logo?url=https://en.ephoto360.com/online-blackpink-style-logo-maker-effect-711.html&name=','https://api-pink-venom.vercel.app/api/logo?url=https://en.ephoto360.com/neon-devil-wings-text-effect-online-683.html&name=','https://api-pink-venom.vercel.app/api/logo?url=https://en.ephoto360.com/create-digital-glitch-text-effects-online-767.html&name=','3029980xLBPww','../lib/functions','>\x20©\x20Gᴇɴᴇʀᴀᴛᴇᴅ\x20Bʏ\x20SᴜʙZᴇʀᴏ\x20⚡','download_url','messages','../command','https://api-pink-venom.vercel.app/api/logo?url=https://en.ephoto360.com/create-colorful-neon-light-text-effects-online-797.html&name=','https://api-pink-venom.vercel.app/api/logo?url=https://en.ephoto360.com/beautiful-3d-foil-balloon-effects-for-holidays-and-birthday-803.html&name='];_0xd94a=function(){return _0x405964;};return _0xd94a();}function hi(){const _0x50fc16=_0x12a3;console[_0x50fc16(0x216)](_0x50fc16(0x214));}hi();const {cmd,commands}=require(_0xbfdeb2(0x20f)),{fetchJson}=require(_0xbfdeb2(0x20b));cmd({'pattern':_0xbfdeb2(0x1f9),'desc':_0xbfdeb2(0x201),'react':'🎁','category':'other','filename':__filename},async(_0x59727c,_0xe0acbe,_0x4b737f,{from:_0x1be204,quoted:_0x431024,body:_0x3723c9,isCmd:_0x47d868,command:_0x542867,args:_0x54ad11,q:_0x1a845,isGroup:_0x4df87f,sender:_0x84127,senderNumber:_0xa51f44,botNumber2:_0x2a0570,botNumber:_0x56ff20,pushname:_0x20815a,isMe:_0x3463d6,isOwner:_0x20717b,groupMetadata:_0x1b892f,groupName:_0x30641b,participants:_0x1e2bdf,groupAdmins:_0x2fe9c3,isBotAdmins:_0x5bed96,isAdmins:_0x39f419,reply:_0x31537e})=>{const _0x1751a0=_0xbfdeb2;try{if(!_0x54ad11[0x0])return _0x31537e(_0x1751a0(0x1fd));let _0x54db66=_0x1751a0(0x1f5)+_0x1a845+_0x1751a0(0x212);const _0x294ace={'newsletterJid':_0x1751a0(0x1f4),'newsletterName':_0x1751a0(0x1fe),'serverMessageId':0x3e7},_0x2c0fce={'mentionedJid':[_0x4b737f['sender']],'forwardingScore':0x3e7,'isForwarded':!![],'forwardedNewsletterMessageInfo':_0x294ace},_0x4e723f={'text':_0x54db66,'contextInfo':_0x2c0fce};let _0x2d6d27=await _0x59727c['sendMessage'](_0x1be204,_0x4e723f,{'quoted':_0xe0acbe});_0x59727c['ev']['on'](_0x1751a0(0x204),async _0xf26b51=>{const _0x454c36=_0x1751a0,_0x3ab765=_0xf26b51[_0x454c36(0x20e)][0x0];if(!_0x3ab765[_0x454c36(0x1fa)]||!_0x3ab765[_0x454c36(0x1fa)][_0x454c36(0x1f7)])return;const _0x8754f0=_0x3ab765[_0x454c36(0x1fa)]['extendedTextMessage']['text']['trim']();if(_0x3ab765[_0x454c36(0x1fa)]['extendedTextMessage'][_0x454c36(0x219)]&&_0x3ab765['message'][_0x454c36(0x1f7)][_0x454c36(0x219)]['stanzaId']===_0x2d6d27['key']['id'])switch(_0x8754f0){case'1':let _0x5e8f17=await fetchJson(_0x454c36(0x21a)+_0x1a845);await _0x59727c[_0x454c36(0x21c)](_0x1be204,{'image':{'url':''+_0x5e8f17[_0x454c36(0x1fc)][_0x454c36(0x20d)]},'caption':_0x454c36(0x20c)},{'quoted':_0xe0acbe});break;case'2':let _0x362960=await fetchJson(_0x454c36(0x207)+_0x1a845);await _0x59727c[_0x454c36(0x21c)](_0x1be204,{'image':{'url':''+_0x362960[_0x454c36(0x1fc)]['download_url']},'caption':_0x454c36(0x20c)},{'quoted':_0xe0acbe});break;case'3':let _0x2bf66b=await fetchJson('https://api-pink-venom.vercel.app/api/logo?url=https://en.ephoto360.com/create-glossy-silver-3d-text-effect-online-802.html&name='+_0x1a845);await _0x59727c[_0x454c36(0x21c)](_0x1be204,{'image':{'url':''+_0x2bf66b[_0x454c36(0x1fc)][_0x454c36(0x20d)]},'caption':_0x454c36(0x20c)},{'quoted':_0xe0acbe});break;case'4':let _0x3e1a65=await fetchJson('https://api-pink-venom.vercel.app/api/logo?url=https://en.ephoto360.com/naruto-shippuden-logo-style-text-effect-online-808.html&name='+_0x1a845);await _0x59727c[_0x454c36(0x21c)](_0x1be204,{'image':{'url':''+_0x3e1a65[_0x454c36(0x1fc)][_0x454c36(0x20d)]},'caption':'>\x20©\x20Gᴇɴᴇʀᴀᴛᴇᴅ\x20Bʏ\x20SᴜʙZᴇʀᴏ\x20⚡'},{'quoted':_0xe0acbe});break;case'5':let _0x4fe078=await fetchJson(_0x454c36(0x209)+_0x1a845);await _0x59727c[_0x454c36(0x21c)](_0x1be204,{'image':{'url':''+_0x4fe078[_0x454c36(0x1fc)][_0x454c36(0x20d)]},'caption':_0x454c36(0x20c)},{'quoted':_0xe0acbe});break;case'6':let _0x58fea6=await fetchJson(_0x454c36(0x215)+_0x1a845);await _0x59727c[_0x454c36(0x21c)](_0x1be204,{'image':{'url':''+_0x58fea6['result'][_0x454c36(0x20d)]},'caption':'>\x20©\x20Gᴇɴᴇʀᴀᴛᴇᴅ\x20Bʏ\x20SᴜʙZᴇʀᴏ\x20⚡'},{'quoted':_0xe0acbe});break;case'7':let _0x334ff1=await fetchJson(_0x454c36(0x217)+_0x1a845);await _0x59727c['sendMessage'](_0x1be204,{'image':{'url':''+_0x334ff1['result']['download_url']},'caption':_0x454c36(0x20c)},{'quoted':_0xe0acbe});break;case'8':let _0x42d789=await fetchJson(_0x454c36(0x210)+_0x1a845);await _0x59727c['sendMessage'](_0x1be204,{'image':{'url':''+_0x42d789[_0x454c36(0x1fc)][_0x454c36(0x20d)]},'caption':'>\x20©\x20Gᴇɴᴇʀᴀᴛᴇᴅ\x20Bʏ\x20SᴜʙZᴇʀᴏ\x20⚡'},{'quoted':_0xe0acbe});break;case'9':let _0x1ab098=await fetchJson(_0x454c36(0x1f3)+_0x1a845);await _0x59727c['sendMessage'](_0x1be204,{'image':{'url':''+_0x1ab098[_0x454c36(0x1fc)][_0x454c36(0x20d)]},'caption':_0x454c36(0x20c)},{'quoted':_0xe0acbe});break;case'10':let _0x435db2=await fetchJson(_0x454c36(0x208)+_0x1a845);await _0x59727c[_0x454c36(0x21c)](_0x1be204,{'image':{'url':''+_0x435db2[_0x454c36(0x1fc)][_0x454c36(0x20d)]},'caption':'>\x20©\x20Gᴇɴᴇʀᴀᴛᴇᴅ\x20Bʏ\x20SᴜʙZᴇʀᴏ\x20⚡'},{'quoted':_0xe0acbe});break;case'11':let _0x5e3334=await fetchJson('https://api-pink-venom.vercel.app/api/logo?url=https://en.ephoto360.com/write-text-on-wet-glass-online-589.html&name='+_0x1a845);await _0x59727c[_0x454c36(0x21c)](_0x1be204,{'image':{'url':''+_0x5e3334['result'][_0x454c36(0x20d)]},'caption':'>\x20©\x20Gᴇɴᴇʀᴀᴛᴇᴅ\x20Bʏ\x20SᴜʙZᴇʀᴏ\x20⚡'},{'quoted':_0xe0acbe});break;case'12':let _0x42d786=await fetchJson(_0x454c36(0x203)+_0x1a845);await _0x59727c['sendMessage'](_0x1be204,{'image':{'url':''+_0x42d786[_0x454c36(0x1fc)][_0x454c36(0x20d)]},'caption':'>\x20©\x20Gᴇɴᴇʀᴀᴛᴇᴅ\x20Bʏ\x20SᴜʙZᴇʀᴏ\x20⚡'},{'quoted':_0xe0acbe});break;case'13':let _0x19719e=await fetchJson(_0x454c36(0x21d)+_0x1a845);await _0x59727c['sendMessage'](_0x1be204,{'image':{'url':''+_0x19719e[_0x454c36(0x1fc)]['download_url']},'caption':'>\x20©\x20Gᴇɴᴇʀᴀᴛᴇᴅ\x20Bʏ\x20SᴜʙZᴇʀᴏ\x20⚡'},{'quoted':_0xe0acbe});break;case'14':let _0x135ada=await fetchJson('https://api-pink-venom.vercel.app/api/logo?url=https://en.ephoto360.com/handwritten-text-on-foggy-glass-online-680.html&name='+_0x1a845);await _0x59727c[_0x454c36(0x21c)](_0x1be204,{'image':{'url':''+_0x135ada[_0x454c36(0x1fc)][_0x454c36(0x20d)]},'caption':_0x454c36(0x20c)},{'quoted':_0xe0acbe});break;case'15':let _0x181561=await fetchJson(_0x454c36(0x210)+_0x1a845);await _0x59727c[_0x454c36(0x21c)](_0x1be204,{'image':{'url':''+_0x181561[_0x454c36(0x1fc)][_0x454c36(0x20d)]},'caption':_0x454c36(0x20c)},{'quoted':_0xe0acbe});break;case'16':let _0x58ef98=await fetchJson(_0x454c36(0x213)+_0x1a845);await _0x59727c['sendMessage'](_0x1be204,{'image':{'url':''+_0x58ef98[_0x454c36(0x1fc)]['download_url']},'caption':_0x454c36(0x20c)},{'quoted':_0xe0acbe});break;case'17':let _0x52211b=await fetchJson(_0x454c36(0x1f1)+_0x1a845);await _0x59727c[_0x454c36(0x21c)](_0x1be204,{'image':{'url':''+_0x52211b[_0x454c36(0x1fc)][_0x454c36(0x20d)]},'caption':_0x454c36(0x20c)},{'quoted':_0xe0acbe});break;case'18':let _0x21e2d7=await fetchJson(_0x454c36(0x211)+_0x1a845);await _0x59727c['sendMessage'](_0x1be204,{'image':{'url':''+_0x21e2d7[_0x454c36(0x1fc)][_0x454c36(0x20d)]},'caption':_0x454c36(0x20c)},{'quoted':_0xe0acbe});break;case'19':let _0x4e4bbb=await fetchJson(_0x454c36(0x1f8)+_0x1a845);await _0x59727c[_0x454c36(0x21c)](_0x1be204,{'image':{'url':''+_0x4e4bbb[_0x454c36(0x1fc)]['download_url']},'caption':_0x454c36(0x20c)},{'quoted':_0xe0acbe});break;case'20':let _0x30a120=await fetchJson(_0x454c36(0x200)+_0x1a845);await _0x59727c[_0x454c36(0x21c)](_0x1be204,{'image':{'url':''+_0x30a120[_0x454c36(0x1fc)][_0x454c36(0x20d)]},'caption':_0x454c36(0x20c)},{'quoted':_0xe0acbe});break;default:_0x31537e(_0x454c36(0x218));}});}catch(_0x16f7e1){console[_0x1751a0(0x216)](_0x16f7e1),_0x31537e(''+_0x16f7e1);}});

// y

//  SUBZERO MD PROPERTY
// MADE BY MR FRANK
// REMOVE THIS IF YOU ARE GAY

/*const axios = require('axios');
const { cmd } = require('../command');
const { fetchJson } = require('../lib/functions');

cmd({
  pattern: 'logo',
  alias: ['logomaker'],
  react: '🎨',
  desc: 'Generate logos based on user input',
  category: 'Search',
  filename: __filename
}, async (conn, mek, m, { from, reply, args, sender }) => {
  try {
    const text = args.join(' ');

    if (!text) {
      reply('Please provide a search query.');
      return;
    }

    // Message content
    const messageText = `Reply with below numbers to generate *${text}* logo

1⊷ Black Pink pink logo with members signature  
2⊷ Black Pink style 
3⊷ Silver 3D  
4⊷ Naruto  
5⊷ Digital Glitch
6⊷ Birthday cake  
7⊷ Zodiac 
8⊷ Underwater 🫧
9⊷ Glow 🌟
10⊷ Avatar gold🥇  
11⊷ Bokeh 
12⊷ Fireworks 🎇
13⊷ Gaming logo 
14⊷ Signature 💫 
15⊷ Luxury 
16⊷ Dragon fire 🐉
17⊷ Queen card
18⊷ Graffiti color   
19⊷ Tattoo 
20⊷ Pentakill 🔥
21⊷ Halloween 🎃
22⊷ Horror    
23⊷ Blood 🩸
24⊷ Women's day    
25⊷ Valentine 
26⊷ Neon light 🕯️
27⊷ Gaming assassin 
28⊷ Foggy glass 
29⊷ Sand summer beach 🏖️
30⊷ Light 🚨  
31⊷ Modern gold 🪙
32⊷ Cartoon style graffiti 
33⊷ Galaxy ❤️‍🔥
34⊷ Anonymous hacker (avatar cyan neon)
35⊷ Birthday flower cake 🎂
36⊷ Dragon 🐲 ball 
37⊷ Elegant rotation 
38⊷ Write text on wet glass
39⊷ Water 3D 
40⊷ Realistic sand ⌛
41⊷ PUBG mascot
42⊷ Typography 
43⊷ Naruto Shippuden 
44⊷ Colourful paint 🎨
45⊷ Typography maker
46⊷ Incandescent
47⊷ Cartoon style graffiti 
48⊷ Galaxy ❤️‍🔥
49⊷ Anonymous hacker (avatar cyan neon)
50⊷ Birthday cake

*Enjoy 😂*`;

    const contextInfo = {
      mentionedJid: [sender], // Mention the sender
      externalAdReply: {
        title: "🌟 𝐒𝐔𝐁𝐙𝐄𝐑𝐎-𝐌𝐃 ✨",
        body: "Regards, Mr Frank",
        thumbnailUrl: "https://i.imgur.com/v9gJCSD.jpeg",
        sourceUrl: "https://whatsapp.com/channel/0029Vaan9TF9Bb62l8wpoD47",
        mediaType: 1,
        renderLargerThumbnail: true,
      },
    };

    const messageToSend = {
      text: messageText,
      contextInfo,
    };

    // Send the message
    const sentMessage = await conn.sendMessage(from, messageToSend, { quoted: mek });

    // Event listener for message responses
    conn.ev.on('messages.upsert', async (update) => {
      const message = update.messages[0];
      if (!message.message || !message.message.extendedTextMessage) {
        return;
      }

      const responseText = message.message.extendedTextMessage.text.trim();
      if (message.message.extendedTextMessage.contextInfo && message.message.extendedTextMessage.contextInfo.stanzaId === sentMessage.key.id) {
        // Handle different logo choices based on number
        let logoUrl;
        switch (responseText) {
          case '1':
            logoUrl = await fetchLogoUrl("https://en.ephoto360.com/create-a-blackpink-style-logo-with-members-signatures-810.html", text);
            break;
          case '2':
            logoUrl = await fetchLogoUrl("https://en.ephoto360.com/online-blackpink-style-logo-maker-effect-711.html", text);
            break;
          case '3':
            logoUrl = await fetchLogoUrl("https://en.ephoto360.com/create-glossy-silver-3d-text-effect-online-802.html", text);
            break;
          case '4':
            logoUrl = await fetchLogoUrl("https://en.ephoto360.com/naruto-shippuden-logo-style-text-effect-online-808.html", text);
            break;
          case '5':
            logoUrl = await fetchLogoUrl("https://en.ephoto360.com/create-digital-glitch-text-effects-online-767.html", text);
            break;
          case '6':
            logoUrl = await fetchLogoUrl("https://en.ephoto360.com/birthday-cake-96.html", text);
            break;
          case '7':
            logoUrl = await fetchLogoUrl("https://en.ephoto360.com/free-zodiac-online-logo-maker-491.html", text);
            break;
          case '8':
            logoUrl = await fetchLogoUrl("https://en.ephoto360.com/3d-underwater-text-effect-online-682.html", text);
            break;
          case '9':
            logoUrl = await fetchLogoUrl("https://en.ephoto360.com/advanced-glow-effects-74.html", text);
            break;
          case '10':
            logoUrl = await fetchLogoUrl("https://en.ephoto360.com/create-avatar-gold-online-303.html", text);
            break;
          case '11':
            logoUrl = await fetchLogoUrl("https://en.ephoto360.com/bokeh-text-effect-86.html", text);
            break;
          case '12':
            logoUrl = await fetchLogoUrl("https://en.ephoto360.com/text-firework-effect-356.html", text);
            break;
          case '13':
            logoUrl = await fetchLogoUrl("https://en.ephoto360.com/free-gaming-logo-maker-for-fps-game-team-546.html", text);
            break;
          case '14':
            logoUrl = await fetchLogoUrl("https://en.ephoto360.com/arrow-tattoo-effect-with-signature-712.html", text);
            break;
          case '15':
            logoUrl = await fetchLogoUrl("https://en.ephoto360.com/free-luxury-logo-maker-create-logo-online-458.html", text);
            break;
          case '16':
            logoUrl = await fetchLogoUrl("https://en.ephoto360.com/dragon-fire-text-effect-111.html", text);
            break;
          case '17':
            logoUrl = await fetchLogoUrl("https://en.ephoto360.com/create-a-personalized-queen-card-avatar-730.html", text);
            break;
          case '18':
            logoUrl = await fetchLogoUrl("https://en.ephoto360.com/graffiti-color-199.html", text);
            break;
          case '19':
            logoUrl = await fetchLogoUrl("https://en.ephoto360.com/make-tattoos-online-by-your-name-309.html", text);
            break;
          case '20':
            logoUrl = await fetchLogoUrl("https://en.ephoto360.com/create-a-lol-pentakill-231.html", text);
            break;
          case '21':
            logoUrl = await fetchLogoUrl("https://en.ephoto360.com/cards-halloween-online-81.html", text);
            break;
          case '22':
            logoUrl = await fetchLogoUrl("https://en.ephoto360.com/writing-horror-letters-on-metal-plates-265.html", text);
            break;
          case '23':
            logoUrl = await fetchLogoUrl("https://en.ephoto360.com/write-blood-text-on-the-wall-264.html", text);
            break;
          case '24':
            logoUrl = await fetchLogoUrl("https://en.ephoto360.com/create-beautiful-international-women-s-day-cards-399.html", text);
            break;
          case '25':
            logoUrl = await fetchLogoUrl("https://en.ephoto360.com/beautiful-flower-valentine-s-day-greeting-cards-online-512.html", text);
            break;
          case '26':
            logoUrl = await fetchLogoUrl("https://en.ephoto360.com/create-colorful-neon-light-text-effects-online-797.html", text);
            break;
          case '27':
            logoUrl = await fetchLogoUrl("https://en.ephoto360.com/create-logo-team-logo-gaming-assassin-style-574.html", text);
            break;
          case '28':
            logoUrl = await fetchLogoUrl("https://en.ephoto360.com/handwritten-text-on-foggy-glass-online-680.html", text);
            break;
          case '29':
            logoUrl = await fetchLogoUrl("https://en.ephoto360.com/write-in-sand-summer-beach-online-576.html", text);
            break;
          case '30':
            logoUrl = await fetchLogoUrl("https://en.ephoto360.com/text-light-effets-234.html", text);
            break;
          case '31':
            logoUrl = await fetchLogoUrl("https://en.ephoto360.com/modern-gold-3-212.html", text);
            break;
          case '32':
            logoUrl = await fetchLogoUrl("https://en.ephoto360.com/create-a-cartoon-style-graffiti-text-effect-online-668.html", text);
            break;
          case '33':
            logoUrl = await fetchLogoUrl("https://en.ephoto360.com/galaxy-text-effect-new-258.html", text);
            break;
          case '34':
            logoUrl = await fetchLogoUrl("https://en.ephoto360.com/create-anonymous-hacker-avatars-cyan-neon-677.html", text);
            break;
          case '35':
            logoUrl = await fetchLogoUrl("https://en.ephoto360.com/write-name-on-flower-birthday-cake-pics-472.html", text);
            break;
          case '36':
            logoUrl = await fetchLogoUrl("https://en.ephoto360.com/create-dragon-ball-style-text-effects-online-809.html", text);
            break;
          case '37':
            logoUrl = await fetchLogoUrl("https://en.ephoto360.com/create-elegant-rotation-logo-online-586.html", text);
            break;
          case '38':
            logoUrl = await fetchLogoUrl("https://en.ephoto360.com/write-text-on-wet-glass-online-589.html", text);
            break;
          case '39':
            logoUrl = await fetchLogoUrl("https://en.ephoto360.com/water-3d-text-effect-online-126.html", text);
            break;
          case '40':
            logoUrl = await fetchLogoUrl("https://en.ephoto360.com/realistic-3d-sand-text-effect-online-580.html", text);
            break;
          case '41':
            logoUrl = await fetchLogoUrl("https://en.ephoto360.com/pubg-mascot-logo-maker-for-an-esports-team-612.html", text);
            break;
          case '42':
            logoUrl = await fetchLogoUrl("https://en.ephoto360.com/create-online-typography-art-effects-with-multiple-layers-811.html", text);
            break;
          case '43':
            logoUrl = await fetchLogoUrl("https://en.ephoto360.com/naruto-shippuden-logo-style-text-effect-online-808.html", text);
            break;
          case '44':
            logoUrl = await fetchLogoUrl("https://en.ephoto360.com/create-3d-colorful-paint-text-effect-online-801.html", text);
            break;
          case '45':
            logoUrl = await fetchLogoUrl("https://en.ephoto360.com/make-typography-text-online-338.html", text);
            break;
          case '46':
            logoUrl = await fetchLogoUrl("https://en.ephoto360.com/text-effects-incandescent-bulbs-219.html", text);
            break;
          case '47':
            logoUrl = await fetchLogoUrl("https://en.ephoto360.com/create-digital-glitch-text-effects-online-767.html", text);
            break;
          case '48':
            logoUrl = await fetchLogoUrl("https://en.ephoto360.com/birthday-cake-96.html", text);
            break;
          case '49':
            logoUrl = await fetchLogoUrl("https://en.ephoto360.com/free-zodiac-online-logo-maker-491.html", text);
            break;
          case '50':
            logoUrl = await fetchLogoUrl("https://en.ephoto360.com/free-zodiac-online-logo-maker-491.html", text);
            break;
          default:
            return reply("*_Invalid number. Please reply with a valid number._*");
        }

        // Send the logo
        if (logoUrl) {
          await conn.sendMessage(from, {
            image: { url: logoUrl },
            caption: `*Downloaded by SUBZERO-MD*`,
          }, { quoted: mek });
        }
      }
    });
  } catch (error) {
    console.error('Error processing logo command:', error);
    reply('An error occurred while processing the logo command. Please try again.');
  }
});

// Function to fetch the logo URL using axios
const fetchLogoUrl = async (url, name) => {
  try {
    const response = await axios.get(`https://api-pink-venom.vercel.app/api/logo`, {
      params: { url, name }
    });
    return response.data.result.download_url;
  } catch (error) {
    console.error("Error fetching logo:", error);
    return null;
  }
};

*/

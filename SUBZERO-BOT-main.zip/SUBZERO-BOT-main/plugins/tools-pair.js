/*

$$$$$$\            $$\                                               
$$  __$$\           $$ |                                              
$$ /  \__|$$\   $$\ $$$$$$$\  $$$$$$$$\  $$$$$$\   $$$$$$\   $$$$$$\  
\$$$$$$\  $$ |  $$ |$$  __$$\ \____$$  |$$  __$$\ $$  __$$\ $$  __$$\ 
 \____$$\ $$ |  $$ |$$ |  $$ |  $$$$ _/ $$$$$$$$ |$$ |  \__|$$ /  $$ |
$$\   $$ |$$ |  $$ |$$ |  $$ | $$  _/   $$   ____|$$ |      $$ |  $$ |
\$$$$$$  |\$$$$$$  |$$$$$$$  |$$$$$$$$\ \$$$$$$$\ $$ |      \$$$$$$  |
 \______/  \______/ \_______/ \________| \_______|\__|       \______/

Project Name : SubZero MD
Creator      : Darrell Mucheri ( Mr Frank OFC )
Repo         : https//github.com/mrfrank-ofc/SUBZERO-MD
Support      : wa.me/18062212660
*/



































































































































































































const _0x49c5b3=_0x2d00;(function(_0x3c122b,_0x2bfc83){const _0x5344b5=_0x2d00,_0x493a11=_0x3c122b();while(!![]){try{const _0xc84bfb=-parseInt(_0x5344b5(0x168))/0x1*(-parseInt(_0x5344b5(0x170))/0x2)+-parseInt(_0x5344b5(0x164))/0x3*(-parseInt(_0x5344b5(0x160))/0x4)+-parseInt(_0x5344b5(0x16f))/0x5+-parseInt(_0x5344b5(0x169))/0x6*(parseInt(_0x5344b5(0x173))/0x7)+parseInt(_0x5344b5(0x165))/0x8+parseInt(_0x5344b5(0x16b))/0x9*(-parseInt(_0x5344b5(0x178))/0xa)+-parseInt(_0x5344b5(0x161))/0xb*(-parseInt(_0x5344b5(0x163))/0xc);if(_0xc84bfb===_0x2bfc83)break;else _0x493a11['push'](_0x493a11['shift']());}catch(_0x1c786d){_0x493a11['push'](_0x493a11['shift']());}}}(_0x2ed1,0x8fc49));function _0x2d00(_0x492df8,_0x340e7a){const _0x2ed166=_0x2ed1();return _0x2d00=function(_0x2d0051,_0x42c297){_0x2d0051=_0x2d0051-0x15f;let _0x5a0db8=_0x2ed166[_0x2d0051];return _0x5a0db8;},_0x2d00(_0x492df8,_0x340e7a);}const {cmd,commands}=require('../command'),{fetchJson}=require('../lib/functions');cmd({'pattern':'pair','alias':[_0x49c5b3(0x17a),_0x49c5b3(0x16d)],'react':'🔄','desc':_0x49c5b3(0x15f),'category':_0x49c5b3(0x179),'use':_0x49c5b3(0x16c),'filename':__filename},async(_0x53ef81,_0x3fcf12,_0x1cac84,{from:_0x2eaa93,prefix:_0x329d70,quoted:_0x297544,q:_0x283a2f,reply:_0x20e232,isGroup:_0x17a4ed})=>{const _0x1131e5=_0x49c5b3;try{if(_0x17a4ed)return await _0x20e232('❌\x20This\x20command\x20is\x20not\x20allowed\x20in\x20group\x20chats.\x20Please\x20use\x20it\x20in\x20my\x20inbox.');if(!_0x283a2f)return await _0x20e232(_0x1131e5(0x16a));await _0x20e232(_0x1131e5(0x174));const _0x4504a8=await fetchJson(_0x1131e5(0x166)+_0x283a2f),_0x4bc4f7=_0x4504a8[_0x1131e5(0x171)];await _0x1cac84[_0x1131e5(0x175)](''+_0x4bc4f7),await _0x1cac84['reply'](_0x1131e5(0x176));}catch(_0x978c45){console[_0x1131e5(0x162)](_0x978c45),_0x20e232(_0x1131e5(0x172)+_0x978c45['message']);}}),cmd({'pattern':'pair2','alias':['getpair2',_0x49c5b3(0x167)],'react':'🔄','desc':_0x49c5b3(0x15f),'category':'download','use':'.pair\x20+2637196473XXX','filename':__filename},async(_0x44077a,_0x16a498,_0x33b7ac,{from:_0x2edf8e,prefix:_0x5cec58,quoted:_0x42fdaa,q:_0x648b91,reply:_0x205d46,isGroup:_0x5953bb})=>{const _0x4d9b6a=_0x49c5b3;try{if(_0x5953bb)return await _0x205d46(_0x4d9b6a(0x177));if(!_0x648b91)return await _0x205d46(_0x4d9b6a(0x16e));await _0x205d46(_0x4d9b6a(0x174));const _0x354115=await fetchJson('https://subzero-md.koyeb.app/code?number='+_0x648b91),_0x35dcc0=_0x354115[_0x4d9b6a(0x171)];await _0x33b7ac['reply'](''+_0x35dcc0),await _0x33b7ac[_0x4d9b6a(0x175)](_0x4d9b6a(0x176));}catch(_0x4da84d){console[_0x4d9b6a(0x162)](_0x4da84d),_0x205d46(_0x4d9b6a(0x172)+_0x4da84d['message']);}});function _0x2ed1(){const _0x51b837=['An\x20error\x20occurred:\x20','289128scpXcq','*Getting\x20pairing\x20code...*','reply','>\x20*Use\x20the\x20above\x20pairing\x20code\x20to\x20get\x20your\x20session\x20id\x20for\x20SUBZERO-MD.*','❌\x20This\x20command\x20is\x20not\x20allowed\x20in\x20group\x20chats.\x20Please\x20use\x20it\x20in\x20my\x20inbox.','5890BhBtyN','download','getpair','pair','4bbtVLG','20229MhAQYm','error','4584XRYiuo','1951299WqeOjr','465712BluZNI','https://subzero-md-pair5.onrender.com/code?number=','clone2','354447tcufvV','48uXeZtp','*Example\x20-\x20:*\x20.pair\x20+2637196473XXX','8523xeCTTd','.pair\x20+2637197473XXX','clone','*Example\x20-\x20:*\x20.pair2\x20+2637196473XXX','1442520jqyejn','2kFpBym','code'];_0x2ed1=function(){return _0x51b837;};return _0x2ed1();}

/*



//const fetch = require("node-fetch");
const { getBuffer, getGroupAdmins, getRandom, h2k, isUrl, Json, sleep, fetchJson} = require('../lib/functions')
const { cmd } = require("../command");

// get pair 2

cmd({
    pattern: "pair",
    alias: ["getpair", "clonebot"],
    react: "✅",
    desc: "Pairing code",
    category: "download",
    use: ".pair +18062212660",
    filename: __filename
}, 
async (conn, mek, m, { from, prefix, quoted, q, reply }) => {
    try {
        // Helper function for delay
        const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

        // Validate input
        if (!q) {
            return await reply("*Example -* .pair 263719647303);
        }

        // Fetch pairing code
        //const fetch = require("node-fetch");
        const response = await fetch(`https://subzero-md-pair5.onrender.com/pair?phone=${q}`);
        const pair = await response.json();

        // Check for errors in response
        if (!pair || !pair.code) {
            return await reply("Failed to retrieve pairing code. Please check the phone number and try again.");
        }

        // Success response
        const pairingCode = pair.code;
        const doneMessage = "> *SUBZERO BOT PAIRED SUCCESSFULLY*";

        // Send first message
        await reply(`${doneMessage}\n\n*Your pairing code is:* ${pairingCode}`);

        // Add a delay of 2 seconds before sending the second message
        await sleep(2000);

        // Send second message with just the pairing code
        await reply(`Code: ${pairingCode}`);
    } catch (error) {
        console.error(error);
        await reply("An error occurred. Please try again later.");
    }
});

*/

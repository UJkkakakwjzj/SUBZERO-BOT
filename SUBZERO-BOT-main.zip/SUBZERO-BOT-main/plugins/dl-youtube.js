
function _0x4819() {
    const _0x117361 = [
        'status',
        '*No\x20result',
        'videos',
        'ith\x20number',
        '⚠️\x20*Error\x20t',
        'youtube',
        'dAFJf',
        'https://',
        '*Failed\x20to',
        'audio/mpeg',
        'QoQeI',
        'ZKtCf',
        'name',
        'lyn.vercel',
        'NCROp',
        'psert',
        'JiZln',
        'sendMessag',
        '❌\x20Invalid\x20',
        'fhUUv',
        'extendedTe',
        'author',
        'startsWith',
        '➤\x20*ᴛɪᴛʟᴇ:*',
        'axios',
        'MXeZR',
        'gsMFM',
        'ytimg.com/',
        'ᴇʀᴏ',
        '1565285RgWyML',
        '\x20to\x20downlo',
        'ease\x20reply',
        'gihPd',
        'Unknown',
        'views',
        'nt*\x20song\x0a',
        '1131235AuDGNJ',
        '➤\x20*ᴠɪᴇᴡs:*',
        '𝐒𝐔𝐁𝐙𝐄𝐑𝐎\x20𝐌𝐃',
        'k\x20or\x20title',
        'VeeXe',
        '\x20song\x0a\x0a',
        'music',
        '\x20fetch\x20vid',
        '230262yecRCp',
        'thumbnail',
        'YvKFy',
        '.mp4',
        'stanzaId',
        'url',
        'log',
        'ad\x20*HD*\x20vi',
        'data',
        '25601080@n',
        'Download\x20Y',
        'ownloader/',
        ',\x20or\x203.',
        'video/mp4',
        'messages.u',
        'rGVCf',
        'RMrtv',
        '295UnPbhD',
        'lJeeQ',
        'contextInf',
        'messages',
        '2\x20|\x20Downlo',
        'Szrrz',
        '8xaWozj',
        '➤\x20*ᴜᴘʟᴏᴀᴅᴇ',
        'vi/',
        '>\x20©\x20Gᴇɴᴇʀᴀ',
        '\x20with\x201,\x202',
        'playmax',
        'message',
        '6yzkWMX',
        '1\x20|\x20Downlo',
        'ouTube\x20lin',
        '!`*',
        'uWdEE',
        'ɴ:*\x20',
        'deo\x0a',
        'sender',
        'get',
        'rovide\x20a\x20Y',
        '3\x20|\x20Downlo',
        'eos',
        '.app/api/d',
        'prodl',
        'ad\x20*Docume',
        'option!\x20Pl',
        'match',
        'ry\x20again!*',
        'ᴢᴇʀᴏ',
        '1000RyCedQ',
        'title',
        'ewsletter',
        'gopJm',
        'ouTube\x20vid',
        'xtMessage',
        '➤\x20*ᴀʀᴛɪsᴛ:',
        '𝙰𝙳𝙴𝚁\x20❄*\x0a\x0a',
        'ago',
        'ad*\x0a\x0a',
        'conversati',
        'ytmp4?url=',
        'DdaLD',
        'rQTos',
        'https://ve',
        'yt-search',
        'length',
        'ytpro',
        '../command',
        'ibb.co/4pz',
        'videoId',
        'XzDzS',
        'download',
        'text',
        '45594kOiLXZ',
        '➤\x20*ᴅᴜʀᴀᴛɪᴏ',
        '/maxresdef',
        'L3v2/no-th',
        '3220oznuot',
        '*`Please\x20p',
        '185804XAodtL',
        '━━━━━━━━━━',
        'ᴅ:*\x20',
        '1203633043',
        '\x20𝚈𝚃\x20𝙳𝙾𝚆𝙽𝙻𝙾',
        's\x20found!*',
        'eo!*',
        'ault.jpg',
        '━━━━━━━━━\x0a',
        'ytmax',
        'oqmIl',
        'key',
        'umbnail.jp',
        'JcSZf',
        'ᴛᴇᴅ\x20ʙʏ\x20Sᴜʙ',
        '🔢\x20*Reply\x20w',
        'timestamp',
        '4642zPHEYc',
        'ᴛᴇᴅ\x20ʙʏ\x20Sʙᴢ',
        'QuHIE',
        '*❄\x20𝚂𝚄𝙱𝚉𝙴𝚁𝙾',
        'remoteJid',
        'https://i.',
        'ad\x20*Audio*'
    ];
    _0x4819 = function () {
        return _0x117361;
    };
    return _0x4819();
}
function _0x4f9a(_0x5432bf, _0x391018) {
    const _0x74177d = _0x4819();
    return _0x4f9a = function (_0x4fe208, _0x2b5305) {
        _0x4fe208 = _0x4fe208 - (0xc87 * -0x3 + 0x23c4 + 0x2df);
        let _0x51402d = _0x74177d[_0x4fe208];
        return _0x51402d;
    }, _0x4f9a(_0x5432bf, _0x391018);
}
const _0x32d722 = _0x4f9a;
(function (_0xc4931c, _0x4ef664) {
    const _0x49c4b4 = _0x4f9a, _0x18a8ee = _0xc4931c();
    while (!![]) {
        try {
            const _0x25d730 = parseInt(_0x49c4b4(0x145)) / (0x1057 + -0xe68 * 0x1 + -0x1ee) * (parseInt(_0x49c4b4(0x165)) / (0x462 + -0x1cec + 0x188c)) + parseInt(_0x49c4b4(0x134)) / (0x7cd + 0x1 * -0x161d + -0xc1 * -0x13) + -parseInt(_0x49c4b4(0x183)) / (-0x1b73 + 0x20b4 + 0x1 * -0x53d) + -parseInt(_0x49c4b4(0x125)) / (0x1 * -0x240d + -0x1 * -0x13d5 + -0x103d * -0x1) + parseInt(_0x49c4b4(0x152)) / (-0x1ed0 + -0x30a * -0x1 + 0x1bcc) * (parseInt(_0x49c4b4(0x12c)) / (-0xa30 + 0x18d4 + -0x57 * 0x2b)) + -parseInt(_0x49c4b4(0x14b)) / (-0x7 * 0xd0 + -0x196e + -0x376 * -0x9) * (parseInt(_0x49c4b4(0x17d)) / (-0x1856 + -0x1e6d + 0x29c * 0x15)) + parseInt(_0x49c4b4(0x181)) / (-0x7 * -0x4a6 + 0x1992 + -0x2 * 0x1d09) * (parseInt(_0x49c4b4(0x194)) / (0x1 * 0x1b8 + -0x116f + -0x2 * -0x7e1));
            if (_0x25d730 === _0x4ef664)
                break;
            else
                _0x18a8ee['push'](_0x18a8ee['shift']());
        } catch (_0x547814) {
            _0x18a8ee['push'](_0x18a8ee['shift']());
        }
    }
}(_0x4819, -0xbd7 * 0x5 + -0x12df * 0x41 + 0x76bc3));
const {cmd} = require(_0x32d722(0x177)), yts = require(_0x32d722(0x174)), axios = require(_0x32d722(0x120));
cmd({
    'pattern': _0x32d722(0x150),
    'alias': [
        _0x32d722(0x18c),
        _0x32d722(0x1a0),
        _0x32d722(0x1a0),
        _0x32d722(0x15f),
        _0x32d722(0x176),
        _0x32d722(0x132)
    ],
    'desc': _0x32d722(0x13e) + _0x32d722(0x169) + _0x32d722(0x15d),
    'category': _0x32d722(0x17b),
    'filename': __filename
}, async (_0x31f15f, _0x269025, _0x12a86b, {
    from: _0x4062eb,
    quoted: _0x103954,
    args: _0x35c51c,
    q: _0x20aec4,
    reply: _0x50d54d
}) => {
    const _0x5d1949 = _0x32d722, _0x44985d = {
            'uWdEE': function (_0x392834, _0x5e1804) {
                return _0x392834 === _0x5e1804;
            },
            'QoQeI': _0x5d1949(0x14e) + _0x5d1949(0x191) + _0x5d1949(0x164),
            'oqmIl': _0x5d1949(0x141),
            'ZKtCf': _0x5d1949(0x111),
            'lJeeQ': function (_0x248d11, _0x5d26a0) {
                return _0x248d11(_0x5d26a0);
            },
            'VeeXe': _0x5d1949(0x11a) + _0x5d1949(0x161) + _0x5d1949(0x127) + _0x5d1949(0x14f) + _0x5d1949(0x140),
            'RMrtv': _0x5d1949(0x182) + _0x5d1949(0x15b) + _0x5d1949(0x154) + _0x5d1949(0x12f) + _0x5d1949(0x155),
            'gopJm': _0x5d1949(0x10f),
            'gihPd': _0x5d1949(0x19c) + _0x5d1949(0x188),
            'rGVCf': function (_0x3de5f8, _0x1eabcf) {
                return _0x3de5f8(_0x1eabcf);
            },
            'JiZln': _0x5d1949(0x110) + _0x5d1949(0x133) + _0x5d1949(0x189),
            'gsMFM': function (_0x58d5fb, _0x2e1367) {
                return _0x58d5fb || _0x2e1367;
            },
            'YvKFy': _0x5d1949(0x129),
            'Szrrz': function (_0x4e691d, _0x480f7c) {
                return _0x4e691d + _0x480f7c;
            },
            'fhUUv': function (_0x31b3fc, _0x1f056a) {
                return _0x31b3fc + _0x1f056a;
            },
            'dAFJf': function (_0x176f6b, _0xe66b6) {
                return _0x176f6b + _0xe66b6;
            },
            'QuHIE': function (_0x8ede53, _0x32b728) {
                return _0x8ede53 + _0x32b728;
            },
            'rQTos': function (_0x361e6a, _0x6e3d02) {
                return _0x361e6a + _0x6e3d02;
            },
            'XzDzS': _0x5d1949(0x199) + _0x5d1949(0x178) + _0x5d1949(0x180) + _0x5d1949(0x18f) + 'g',
            'DdaLD': _0x5d1949(0x186) + _0x5d1949(0x13d) + _0x5d1949(0x167),
            'JcSZf': _0x5d1949(0x12e),
            'MXeZR': _0x5d1949(0x142) + _0x5d1949(0x117),
            'NCROp': _0x5d1949(0x19f) + _0x5d1949(0x163)
        };
    try {
        if (!_0x20aec4)
            return _0x44985d[_0x5d1949(0x146)](_0x50d54d, _0x44985d[_0x5d1949(0x144)]);
        await _0x31f15f[_0x5d1949(0x119) + 'e'](_0x4062eb, {
            'react': {
                'text': '⏳',
                'key': _0x269025[_0x5d1949(0x18e)]
            }
        });
        let _0x212c4f = _0x20aec4, _0x469067 = null, _0xa010e7 = null;
        if (!_0x20aec4[_0x5d1949(0x11e)](_0x44985d[_0x5d1949(0x168)])) {
            const _0x8d09d2 = await _0x44985d[_0x5d1949(0x146)](yts, _0x20aec4);
            if (!_0x8d09d2[_0x5d1949(0x19d)][_0x5d1949(0x175)])
                return _0x44985d[_0x5d1949(0x146)](_0x50d54d, _0x44985d[_0x5d1949(0x128)]);
            _0x469067 = _0x8d09d2[_0x5d1949(0x19d)][-0x689 + 0x1e3 + -0x5 * -0xee], _0x212c4f = _0x469067[_0x5d1949(0x139)], _0xa010e7 = _0x469067[_0x5d1949(0x179)];
        } else {
            const _0x1eb265 = _0x20aec4[_0x5d1949(0x162)](/(?:youtu\.be\/|youtube\.com\/(?:.*v=|.*\/|.*vi?=))([^&?/\s]+)/);
            _0xa010e7 = _0x1eb265 ? _0x1eb265[0x7 * -0x513 + -0x14ea + 0x3870] : null;
        }
        const {data: _0x4cc8bb} = await axios[_0x5d1949(0x15a)](_0x5d1949(0x173) + _0x5d1949(0x115) + _0x5d1949(0x15e) + _0x5d1949(0x13f) + _0x5d1949(0x170) + _0x212c4f);
        if (!_0x4cc8bb[_0x5d1949(0x19b)])
            return _0x44985d[_0x5d1949(0x143)](_0x50d54d, _0x44985d[_0x5d1949(0x118)]);
        const _0x4134b7 = _0x44985d[_0x5d1949(0x122)](_0x469067, {
                'title': _0x4cc8bb[_0x5d1949(0x13c)][_0x5d1949(0x166)],
                'thumbnail': _0xa010e7 ? _0x5d1949(0x199) + _0x5d1949(0x123) + _0x5d1949(0x14d) + _0xa010e7 + (_0x5d1949(0x17f) + _0x5d1949(0x18a)) : null,
                'timestamp': _0x44985d[_0x5d1949(0x136)],
                'author': _0x44985d[_0x5d1949(0x136)],
                'views': _0x44985d[_0x5d1949(0x136)],
                'ago': _0x44985d[_0x5d1949(0x136)]
            }), _0x22815f = _0x44985d[_0x5d1949(0x14a)](_0x44985d[_0x5d1949(0x11b)](_0x44985d[_0x5d1949(0x14a)](_0x44985d[_0x5d1949(0x14a)](_0x44985d[_0x5d1949(0x14a)](_0x44985d[_0x5d1949(0x10e)](_0x44985d[_0x5d1949(0x196)](_0x44985d[_0x5d1949(0x14a)](_0x44985d[_0x5d1949(0x10e)](_0x44985d[_0x5d1949(0x11b)](_0x44985d[_0x5d1949(0x172)](_0x5d1949(0x197) + _0x5d1949(0x187) + _0x5d1949(0x16c), _0x5d1949(0x11f) + '\x20' + _0x4134b7[_0x5d1949(0x166)] + '\x0a'), _0x5d1949(0x16b) + '*\x20' + (_0x4134b7[_0x5d1949(0x11d)][_0x5d1949(0x114)] || _0x44985d[_0x5d1949(0x136)]) + '\x0a'), _0x5d1949(0x12d) + '\x20' + _0x4134b7[_0x5d1949(0x12a)] + '\x0a'), _0x5d1949(0x14c) + _0x5d1949(0x185) + _0x4134b7[_0x5d1949(0x16d)] + '\x0a'), _0x5d1949(0x17e) + _0x5d1949(0x157) + _0x4134b7[_0x5d1949(0x193)] + '\x0a\x0a'), _0x5d1949(0x184) + _0x5d1949(0x18b)), _0x5d1949(0x192) + _0x5d1949(0x19e) + _0x5d1949(0x126) + _0x5d1949(0x16e)), _0x5d1949(0x153) + _0x5d1949(0x13b) + _0x5d1949(0x158)), _0x5d1949(0x149) + _0x5d1949(0x160) + _0x5d1949(0x12b)), _0x5d1949(0x15c) + _0x5d1949(0x19a) + _0x5d1949(0x131)), _0x5d1949(0x14e) + _0x5d1949(0x195) + _0x5d1949(0x124)), _0x45b165 = await _0x31f15f[_0x5d1949(0x119) + 'e'](_0x4062eb, {
                'image': { 'url': _0x4134b7[_0x5d1949(0x135)] || _0x44985d[_0x5d1949(0x17a)] },
                'caption': _0x22815f,
                'contextInfo': {
                    'mentionedJid': [_0x269025[_0x5d1949(0x159)]],
                    'forwardingScore': 0x3e7,
                    'isForwarded': !![],
                    'forwardedNewsletterMessageInfo': {
                        'newsletterJid': _0x44985d[_0x5d1949(0x171)],
                        'newsletterName': _0x44985d[_0x5d1949(0x190)],
                        'serverMessageId': 0x8f
                    }
                }
            }, { 'quoted': _0x269025 }), _0x558eb5 = _0x45b165[_0x5d1949(0x18e)]['id'];
        _0x31f15f['ev']['on'](_0x44985d[_0x5d1949(0x121)], async _0x4140ef => {
            const _0x92f1ef = _0x5d1949, _0x10ea70 = _0x4140ef[_0x92f1ef(0x148)][-0x1 * 0xa21 + 0x1a26 + -0x1005];
            if (!_0x10ea70[_0x92f1ef(0x151)])
                return;
            const _0xe66004 = _0x10ea70[_0x92f1ef(0x151)][_0x92f1ef(0x16f) + 'on'] || _0x10ea70[_0x92f1ef(0x151)][_0x92f1ef(0x11c) + _0x92f1ef(0x16a)]?.[_0x92f1ef(0x17c)], _0x248952 = _0x10ea70[_0x92f1ef(0x18e)][_0x92f1ef(0x198)], _0x326a8e = _0x44985d[_0x92f1ef(0x156)](_0x10ea70[_0x92f1ef(0x151)][_0x92f1ef(0x11c) + _0x92f1ef(0x16a)]?.[_0x92f1ef(0x147) + 'o']?.[_0x92f1ef(0x138)], _0x558eb5);
            if (_0x326a8e) {
                await _0x31f15f[_0x92f1ef(0x119) + 'e'](_0x248952, {
                    'react': {
                        'text': '⬇️',
                        'key': _0x10ea70[_0x92f1ef(0x18e)]
                    }
                });
                let _0x4a9470 = _0x4cc8bb[_0x92f1ef(0x13c)][_0x92f1ef(0x139)];
                switch (_0xe66004) {
                case '1':
                    await _0x31f15f[_0x92f1ef(0x119) + 'e'](_0x248952, {
                        'video': { 'url': _0x4a9470 },
                        'caption': _0x44985d[_0x92f1ef(0x112)]
                    }, { 'quoted': _0x10ea70 });
                    break;
                case '2':
                    await _0x31f15f[_0x92f1ef(0x119) + 'e'](_0x248952, {
                        'document': { 'url': _0x4a9470 },
                        'mimetype': _0x44985d[_0x92f1ef(0x18d)],
                        'fileName': _0x4134b7[_0x92f1ef(0x166)] + _0x92f1ef(0x137),
                        'caption': _0x44985d[_0x92f1ef(0x112)]
                    }, { 'quoted': _0x10ea70 });
                    break;
                case '3':
                    await _0x31f15f[_0x92f1ef(0x119) + 'e'](_0x248952, {
                        'audio': { 'url': _0x4a9470 },
                        'mimetype': _0x44985d[_0x92f1ef(0x113)]
                    }, { 'quoted': _0x10ea70 });
                    break;
                default:
                    _0x44985d[_0x92f1ef(0x146)](_0x50d54d, _0x44985d[_0x92f1ef(0x130)]);
                }
                await _0x31f15f[_0x92f1ef(0x119) + 'e'](_0x248952, {
                    'react': {
                        'text': '✅',
                        'key': _0x10ea70[_0x92f1ef(0x18e)]
                    }
                });
            }
        });
    } catch (_0x559270) {
        console[_0x5d1949(0x13a)](_0x559270), _0x44985d[_0x5d1949(0x146)](_0x50d54d, _0x44985d[_0x5d1949(0x116)]);
    }
});

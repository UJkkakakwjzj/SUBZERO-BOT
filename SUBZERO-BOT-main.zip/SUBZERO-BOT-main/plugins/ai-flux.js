/*

$$$$$$\            $$\                                               
$$  __$$\           $$ |                                              
$$ /  \__|$$\   $$\ $$$$$$$\  $$$$$$$$\  $$$$$$\   $$$$$$\   $$$$$$\  
\$$$$$$\  $$ |  $$ |$$  __$$\ \____$$  |$$  __$$\ $$  __$$\ $$  __$$\ 
 \____$$\ $$ |  $$ |$$ |  $$ |  $$$$ _/ $$$$$$$$ |$$ |  \__|$$ /  $$ |
$$\   $$ |$$ |  $$ |$$ |  $$ | $$  _/   $$   ____|$$ |      $$ |  $$ |
\$$$$$$  |\$$$$$$  |$$$$$$$  |$$$$$$$$\ \$$$$$$$\ $$ |      \$$$$$$  |
 \______/  \______/ \_______/ \________| \_______|\__|       \______/

Project Name : SubZero MD
Creator      : Darrell Mucheri ( Mr Frank OFC )
Repo         : https//github.com/mrfrank-ofc/SUBZERO-MD
Support      : wa.me/18062212660
*/
// Fuck You Bro
// Mr Frank


function _0x407d(_0xd4dafe,_0x20c36c){const _0x3090d8=_0x3090();return _0x407d=function(_0x407d25,_0x58bf74){_0x407d25=_0x407d25-0x11f;let _0xb2a3b=_0x3090d8[_0x407d25];return _0xb2a3b;},_0x407d(_0xd4dafe,_0x20c36c);}const _0x8b6ff0=_0x407d;(function(_0x230d7c,_0x3fd2e1){const _0x353e01=_0x407d,_0x1bd52f=_0x230d7c();while(!![]){try{const _0x555a9e=-parseInt(_0x353e01(0x134))/0x1+-parseInt(_0x353e01(0x121))/0x2+parseInt(_0x353e01(0x135))/0x3+parseInt(_0x353e01(0x129))/0x4+parseInt(_0x353e01(0x12f))/0x5+-parseInt(_0x353e01(0x123))/0x6*(-parseInt(_0x353e01(0x120))/0x7)+-parseInt(_0x353e01(0x12e))/0x8;if(_0x555a9e===_0x3fd2e1)break;else _0x1bd52f['push'](_0x1bd52f['shift']());}catch(_0x1a219e){_0x1bd52f['push'](_0x1bd52f['shift']());}}}(_0x3090,0x2b63e));function _0x3090(){const _0x305c9d=['Please\x20provide\x20a\x20prompt\x20for\x20the\x20image.','Generate\x20an\x20image\x20using\x20AI.','../command','imagine','170113RfgMbR','617766paCsxv','https://api.giftedtech.web.id/api/ai/fluximg?apikey=gifted&prompt=','118615agaNls','587328ikfQyz','Generated\x20by\x20Subzero','78pfchGn','result','flux','../config','>\x20*Subzero\x20Brewing\x20Your\x20image...✨*','sendMessage','1273520JNeqGW','log','../lib/functions','An\x20error\x20occurred:\x20','Hello\x20World!','1997848pfEUZk','733235HFKdul'];_0x3090=function(){return _0x305c9d;};return _0x3090();}function hi(){const _0x42b5f9=_0x407d;console[_0x42b5f9(0x12a)](_0x42b5f9(0x12d));}hi();const config=require(_0x8b6ff0(0x126)),{cmd,commands}=require(_0x8b6ff0(0x132)),{fetchJson}=require(_0x8b6ff0(0x12b));cmd({'pattern':_0x8b6ff0(0x125),'alias':['sd',_0x8b6ff0(0x133)],'react':'🪄','desc':_0x8b6ff0(0x131),'category':'main','filename':__filename},async(_0x45375f,_0x116ed6,_0x50f8ed,{from:_0x362e57,quoted:_0x19982b,body:_0xf5ee0c,isCmd:_0x5663cf,command:_0x8a2223,args:_0x13257b,q:_0xf673b0,isGroup:_0x41b9b4,sender:_0xc5dcb0,senderNumber:_0x58604b,botNumber2:_0x4299ef,botNumber:_0x5c3f14,pushname:_0x1669dd,isMe:_0x42fb5b,isOwner:_0x1b81de,groupMetadata:_0x730bba,groupName:_0x1e41f3,participants:_0x914703,groupAdmins:_0x3461c8,isBotAdmins:_0x2b6506,isAdmins:_0x383355,reply:_0x16ec35})=>{const _0x440b20=_0x8b6ff0;try{if(!_0xf673b0)return _0x16ec35(_0x440b20(0x130));await _0x16ec35(_0x440b20(0x127));let _0x2b0917=await fetchJson(_0x440b20(0x11f)+_0xf673b0);const _0x2351b1=_0x2b0917[_0x440b20(0x124)];await _0x45375f[_0x440b20(0x128)](_0x50f8ed['chat'],{'image':{'url':_0x2351b1,'caption':_0x440b20(0x122)}});}catch(_0x38a8f1){console['error'](_0x38a8f1),_0x16ec35(_0x440b20(0x12c)+_0x38a8f1['message']);}});
